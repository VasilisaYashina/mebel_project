from flask import Flask
from flask import render_template, redirect
import requests
from flask import request
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = '/static/img'

global flag_reg, profile, dic
flag_reg = False
profile = "фт.png"
dic ={1: "жаба-значок.png",
      2: "корова-значок.png",
      3: "кот-значок.png",
      4: "крокодил-значок.png",
      5: "овца-значок.png",
      6: "слон-значок.png",
      7: "собака-значок.png"}

@app.route('/')
def wares_page():
    return render_template('mades.html', user=profile)

@app.route('/home_page')
def home_page():
    return render_template('home.html', user=profile)

@app.route('/reviews', methods=['GET', 'POST'])
def reviews_page():
    sl = {"1": "Ужасно",
          "2": "Нормально",
          "3": "Великолепно",
          "Теперь оцените качество нашего обслуживания": "нет оценки",
          "Оцените качество товара": "нет оценки",
          "Для начала оцените наш сайт": "нет оценки"}
    if flag_reg is False:
        return redirect('/login')
    else:
        if request.method == "POST":
            if 'note_button' in request.form:
                x = sl[request.form["mark"]]
                y = sl[request.form["quality"]]
                z = sl[request.form["purchase"]]
                a = request.form["comment"]
                f = request.files['file']
                acc = request.form["ac_c"]
                print(acc)
                #f.save(f.filename)
                post_wall(x, y, z, a, acc)
        return render_template('notes.html', user=profile)

@app.route('/contacts')
def contacts_page():
    return render_template('contacts.html', user=profile)

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == "POST":
        if 'enter_button' in request.form:
            if len(request.form["exampleInputPassword1"]) > 0 and len(request.form["exampleInputEmail1"]) > 0:
                if check_reg(request.form["exampleInputEmail1"], request.form["exampleInputPassword1"]):
                    if check_pass(request.form["exampleInputEmail1"], request.form["exampleInputPassword1"]):
                        global flag_reg, profile, dic
                        flag_reg = True
                        profile = dic[random.randrange(1, 7)]
                        return redirect('/reviews')
                    else:
                        return "Неправильный пароль"
                else:
                    return "Пользователь с таким email не зарегистрирован"
        elif 'reg_button' in request.form:

            if len(request.form["exampleInputPassword1"]) > 0 and len(request.form["exampleInputEmail1"]) > 0:
                if check_reg(request.form["exampleInputEmail1"], request.form["exampleInputPassword1"]):
                    return "Email занят"
                else:
                    add_user(request.form["exampleInputEmail1"], request.form["exampleInputPassword1"])
                    return redirect('/reviews')
    return render_template('reg.html', user=profile)

def check_reg(a, b):
    #проверка зарегестрирован ли пользователь
    #sl = auth(a, b)
    #или register(a, b)
    #смотрим на значение в словаре, и делаем выводы
    return True

def check_pass(a, b):
    #проверка совпадения пароля
    #sl = auth(a, b)
    # смотрим на значение в словаре, и делаем выводы
    return True

def add_user(a, b):
    #добавление пользователя в систему
    #просто прописать в базе данных
    pass

def post_wall(r1, r2, r3, com, acc_t):
    access_token = acc_t
    url = 'https://api.vk.com/method/'
    token = '&access_token=' + access_token
    ver = '&v=5.81'
    params = 'owner_id=-212860303'
    text = f"""Приветик всем! Нам пришел еще один приятный отзыв:)
            1) Оценка сайта: {r1}
            2) Оценка качества нашего обслуживания: {r2}
            3) Оценка качества товара: {r3}
            4) Комментарий: {com}"""
    message = '&message=' + text
    method = 'wall.post?'
    url = url + method + params + message + token + ver
    data = requests.get(url)
    print(data.text)

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')